// Константы игры
const DIFFICULTY = {
	easy: {
		width: 9,
		height: 9,
		mines: 10
	},
	medium: {
		width: 16,
		height: 16,
		mines: 40
	},
	hard: {
		width: 16,
		height: 30,
		mines: 99
	}
};

// Состояние игры
let gameState = {
	gameId: null,
	difficulty: 'easy',
	board: null,
	startTime: null,
	timer: null
};

// Функция для получения токена
const getAuthToken = () => localStorage.getItem('token');

// Функция для проверки авторизации
const checkAuthRequired = () => {
	if (!getAuthToken()) {
		alert('Для игры необходимо авторизоваться');
		return false;
	}
	return true;
};

// Функция для форматирования времени
const formatTime = (seconds) => {
	const minutes = Math.floor(seconds / 60);
	const remainingSeconds = seconds % 60;
	return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
};

// Функция для обновления таймера
const updateTimer = () => {
	if (!gameState.startTime) return;

	const timeElement = document.getElementById('time');
	if (!timeElement) return;

	const currentTime = Math.floor((Date.now() - gameState.startTime) / 1000);
	timeElement.textContent = formatTime(currentTime);
};

// Функция для начала новой игры
const startNewGame = async (difficulty) => {
	if (!checkAuthRequired()) return;

	try {
		const response = await fetch('/api/game/start', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': `Bearer ${getAuthToken()}`
			},
			body: JSON.stringify({ difficulty })
		});

		const data = await response.json();

		if (response.ok) {
			gameState = {
				...gameState,
				gameId: data.gameId,
				difficulty,
				board: data.board,
				startTime: Date.now()
			};

			// Запускаем таймер
			if (gameState.timer) clearInterval(gameState.timer);
			gameState.timer = setInterval(updateTimer, 1000);

			// Обновляем UI
			updateGameBoard();
			updateMineCounter();
		} else {
			alert(data.message);
		}
	} catch (error) {
		console.error('Ошибка при начале новой игры:', error);
		alert('Произошла ошибка при начале игры');
	}
};

// Функция для обновления счетчика мин
const updateMineCounter = () => {
	const mineCounter = document.getElementById('mines');
	if (!mineCounter) return;

	const flaggedCount = gameState.board.flagged.flat().filter(Boolean).length;
	const totalMines = DIFFICULTY[gameState.difficulty].mines;
	mineCounter.textContent = totalMines - flaggedCount;
};

// Функция для создания игрового поля
const createGameBoard = () => {
	const boardElement = document.getElementById('game-board');
	if (!boardElement) return;

	const { width, height } = DIFFICULTY[gameState.difficulty];

	boardElement.innerHTML = '';
	boardElement.style.gridTemplateColumns = `repeat(${width}, 30px)`;

	for (let y = 0; y < height; y++) {
		for (let x = 0; x < width; x++) {
			const cell = document.createElement('div');
			cell.className = 'cell';
			cell.dataset.x = x;
			cell.dataset.y = y;

			// Добавляем обработчики событий
			cell.addEventListener('click', () => handleCellClick(x, y));
			cell.addEventListener('contextmenu', (e) => {
				e.preventDefault();
				handleCellRightClick(x, y);
			});

			boardElement.appendChild(cell);
		}
	}
};

// Функция для обновления состояния игрового поля
const updateGameBoard = () => {
	const boardElement = document.getElementById('game-board');
	if (!boardElement) return;

	const cells = boardElement.getElementsByClassName('cell');
	const { width, height } = DIFFICULTY[gameState.difficulty];

	for (let y = 0; y < height; y++) {
		for (let x = 0; x < width; x++) {
			const cell = cells[y * width + x];
			const isRevealed = gameState.board.revealed[y][x];
			const isFlagged = gameState.board.flagged[y][x];

			cell.className = 'cell';
			if (isRevealed) {
				cell.classList.add('revealed');
				// Если игра завершена и здесь мина
				if (gameState.board.mines && gameState.board.mines[y][x]) {
					cell.classList.add('mine');
				}
			}
			if (isFlagged) {
				cell.classList.add('flagged');
			}
		}
	}
};

// Обработчик клика по ячейке
const handleCellClick = async (x, y) => {
	if (!gameState.gameId) return;

	try {
		const response = await fetch(`/api/game/${gameState.gameId}/move`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': `Bearer ${getAuthToken()}`
			},
			body: JSON.stringify({ x, y, type: 'reveal' })
		});

		const data = await response.json();

		if (response.ok) {
			gameState.board = data.board;
			updateGameBoard();
			updateMineCounter();

			if (data.result !== 'in_progress') {
				handleGameEnd(data.result);
			}
		} else {
			alert(data.message);
		}
	} catch (error) {
		console.error('Ошибка при совершении хода:', error);
		alert('Произошла ошибка при совершении хода');
	}
};

// Обработчик правого клика по ячейке (установка флага)
const handleCellRightClick = async (x, y) => {
	if (!gameState.gameId) return;

	try {
		const response = await fetch(`/api/game/${gameState.gameId}/move`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': `Bearer ${getAuthToken()}`
			},
			body: JSON.stringify({ x, y, type: 'flag' })
		});

		const data = await response.json();

		if (response.ok) {
			gameState.board = data.board;
			updateGameBoard();
			updateMineCounter();
		} else {
			alert(data.message);
		}
	} catch (error) {
		console.error('Ошибка при установке флага:', error);
		alert('Произошла ошибка при установке флага');
	}
};

// Функция обработки окончания игры
const handleGameEnd = (result) => {
	// Останавливаем таймер
	if (gameState.timer) {
		clearInterval(gameState.timer);
		gameState.timer = null;
	}

	// Показываем сообщение
	const message = result === 'victory' ? 'Поздравляем! Вы победили!' : 'Игра окончена. Вы проиграли.';
	setTimeout(() => {
		alert(message);
	}, 100);
};

// Инициализация игры при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
	// Создаем игровое поле
	createGameBoard();

	// Добавляем обработчики для кнопок выбора сложности
	const difficultyButtons = document.querySelectorAll('.difficulty-button');
	difficultyButtons.forEach(button => {
		button.addEventListener('click', () => {
			const difficulty = button.dataset.difficulty;
			if (difficulty) {
				startNewGame(difficulty);
			}
		});
	});

	// Добавляем обработчик для кнопки новой игры
	const newGameButton = document.getElementById('new-game');
	if (newGameButton) {
		newGameButton.addEventListener('click', () => {
			startNewGame(gameState.difficulty);
		});
	}
}); 