// Константы игры
const MINE = '💣';
const FLAG = '🚩';
const EMPTY = '';

// Настройки сложности
const DIFFICULTY_SETTINGS = {
	easy: { rows: 8, cols: 8, mines: 10 },
	medium: { rows: 16, cols: 16, mines: 40 },
	hard: { rows: 16, cols: 30, mines: 99 }
};

// Состояние игры
let gameState = {
	board: [],
	mineLocations: new Set(),
	flaggedCells: new Set(),
	revealedCells: new Set(),
	gameStarted: false,
	gameOver: false,
	difficulty: 'easy',
	startTime: null,
	timer: null,
	minesLeft: 0
};

// DOM элементы
const gameBoard = document.getElementById('gameBoard');
const minesLeftDisplay = document.getElementById('minesLeft');
const timerDisplay = document.getElementById('timer');
const difficultyButtons = document.querySelectorAll('.difficulty-button');
const newGameButton = document.getElementById('newGameButton');

// Инициализация игры
function initGame(difficulty = 'easy') {
	clearInterval(gameState.timer);
	gameState = {
		...gameState,
		board: [],
		mineLocations: new Set(),
		flaggedCells: new Set(),
		revealedCells: new Set(),
		gameStarted: false,
		gameOver: false,
		difficulty: difficulty,
		startTime: null,
		timer: null,
		minesLeft: DIFFICULTY_SETTINGS[difficulty].mines
	};

	createBoard();
	updateMinesLeft();
	timerDisplay.textContent = '00:00';
}

// Создание игрового поля
function createBoard() {
	const { rows, cols } = DIFFICULTY_SETTINGS[gameState.difficulty];
	gameBoard.innerHTML = '';
	gameBoard.style.gridTemplateColumns = `repeat(${cols}, 30px)`;

	for (let i = 0; i < rows; i++) {
		gameState.board[i] = [];
		for (let j = 0; j < cols; j++) {
			const cell = document.createElement('div');
			cell.className = 'cell';
			cell.dataset.row = i;
			cell.dataset.col = j;

			cell.addEventListener('click', () => handleCellClick(i, j));
			cell.addEventListener('contextmenu', (e) => {
				e.preventDefault();
				handleRightClick(i, j);
			});

			gameBoard.appendChild(cell);
			gameState.board[i][j] = 0;
		}
	}
}

// Размещение мин
function placeMines(firstRow, firstCol) {
	const { rows, cols, mines } = DIFFICULTY_SETTINGS[gameState.difficulty];

	while (gameState.mineLocations.size < mines) {
		const row = Math.floor(Math.random() * rows);
		const col = Math.floor(Math.random() * cols);

		// Проверяем, что мина не ставится на первую открытую клетку или рядом с ней
		if (Math.abs(row - firstRow) <= 1 && Math.abs(col - firstCol) <= 1) {
			continue;
		}

		const key = `${row},${col}`;
		if (!gameState.mineLocations.has(key)) {
			gameState.mineLocations.add(key);
			gameState.board[row][col] = MINE;

			// Увеличиваем счетчики соседних клеток
			for (let i = -1; i <= 1; i++) {
				for (let j = -1; j <= 1; j++) {
					if (i === 0 && j === 0) continue;

					const newRow = row + i;
					const newCol = col + j;

					if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols &&
						gameState.board[newRow][newCol] !== MINE) {
						gameState.board[newRow][newCol]++;
					}
				}
			}
		}
	}
}

// Обработка клика по клетке
function handleCellClick(row, col) {
	if (gameState.gameOver) return;

	const cell = getCellElement(row, col);
	if (cell.classList.contains('flagged')) return;

	if (!gameState.gameStarted) {
		gameState.gameStarted = true;
		gameState.startTime = Date.now();
		startTimer();
		placeMines(row, col);
	}

	revealCell(row, col);
}

// Обработка правого клика (установка флага)
function handleRightClick(row, col) {
	if (gameState.gameOver || !gameState.gameStarted) return;

	const key = `${row},${col}`;
	const cell = getCellElement(row, col);

	if (!cell.classList.contains('revealed')) {
		if (cell.classList.contains('flagged')) {
			cell.classList.remove('flagged');
			cell.textContent = EMPTY;
			gameState.flaggedCells.delete(key);
			gameState.minesLeft++;
		} else {
			cell.classList.add('flagged');
			cell.textContent = FLAG;
			gameState.flaggedCells.add(key);
			gameState.minesLeft--;
		}
		updateMinesLeft();
		checkWinCondition();
	}
}

// Открытие клетки
function revealCell(row, col) {
	const { rows, cols } = DIFFICULTY_SETTINGS[gameState.difficulty];
	const key = `${row},${col}`;

	if (gameState.revealedCells.has(key) || gameState.flaggedCells.has(key)) return;

	const cell = getCellElement(row, col);
	cell.classList.add('revealed');
	gameState.revealedCells.add(key);

	if (gameState.mineLocations.has(key)) {
		gameOver(false);
		return;
	}

	const value = gameState.board[row][col];
	if (value > 0) {
		cell.textContent = value;
		cell.classList.add(`mines-${value}`);
	} else {
		// Рекурсивно открываем соседние пустые клетки
		for (let i = -1; i <= 1; i++) {
			for (let j = -1; j <= 1; j++) {
				const newRow = row + i;
				const newCol = col + j;

				if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) {
					revealCell(newRow, newCol);
				}
			}
		}
	}

	checkWinCondition();
}

// Проверка условия победы
function checkWinCondition() {
	const { rows, cols, mines } = DIFFICULTY_SETTINGS[gameState.difficulty];
	const totalCells = rows * cols;

	if (gameState.revealedCells.size === totalCells - mines &&
		gameState.flaggedCells.size === mines) {
		gameOver(true);
	}
}

// Завершение игры
function gameOver(isWin) {
	gameState.gameOver = true;
	clearInterval(gameState.timer);

	// Показываем все мины
	gameState.mineLocations.forEach(key => {
		const [row, col] = key.split(',').map(Number);
		const cell = getCellElement(row, col);
		if (!cell.classList.contains('flagged')) {
			cell.classList.add('revealed');
			cell.textContent = MINE;
		}
	});

	// Отправляем результат на сервер
	if (isWin) {
		const time = Math.floor((Date.now() - gameState.startTime) / 1000);
		sendGameResult(time);
		alert('Поздравляем! Вы победили!');
	} else {
		alert('Игра окончена! Вы проиграли.');
	}
}

// Отправка результата игры
async function sendGameResult(time) {
	try {
		const token = localStorage.getItem('token');
		if (!token) return;

		const response = await fetch('/api/games', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': `Bearer ${token}`
			},
			body: JSON.stringify({
				difficulty: gameState.difficulty,
				time: time
			})
		});

		if (response.ok) {
			const result = await response.json();
			// Проверяем, получены ли новые достижения
			if (result.achievements && result.achievements.length > 0) {
				showNewAchievements(result.achievements);
			}
		}
	} catch (error) {
		console.error('Ошибка при отправке результата:', error);
	}
}

// Показ новых достижений
function showNewAchievements(achievements) {
	const achievementsList = achievements.map(a =>
		`<div class="achievement-notification">
            <img src="${a.icon}" alt="${a.name}">
            <div>
                <h3>${a.name}</h3>
                <p>${a.description}</p>
            </div>
        </div>`
	).join('');

	const modal = document.createElement('div');
	modal.className = 'achievements-modal';
	modal.innerHTML = `
        <div class="achievements-modal-content">
            <h2>Новые достижения!</h2>
            ${achievementsList}
            <button onclick="this.parentElement.parentElement.remove()">OK</button>
        </div>
    `;

	document.body.appendChild(modal);
}

// Вспомогательные функции
function getCellElement(row, col) {
	return document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
}

function updateMinesLeft() {
	minesLeftDisplay.textContent = gameState.minesLeft;
}

function startTimer() {
	gameState.timer = setInterval(() => {
		const time = Math.floor((Date.now() - gameState.startTime) / 1000);
		const minutes = Math.floor(time / 60).toString().padStart(2, '0');
		const seconds = (time % 60).toString().padStart(2, '0');
		timerDisplay.textContent = `${minutes}:${seconds}`;
	}, 1000);
}

// Обработчики событий
difficultyButtons.forEach(button => {
	button.addEventListener('click', () => {
		const difficulty = button.dataset.difficulty;
		difficultyButtons.forEach(btn => btn.classList.remove('active'));
		button.classList.add('active');
		initGame(difficulty);
	});
});

newGameButton.addEventListener('click', () => {
	initGame(gameState.difficulty);
});

// Инициализация игры при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
	initGame();
}); 