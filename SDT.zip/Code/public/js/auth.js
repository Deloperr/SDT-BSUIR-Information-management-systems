// Элементы DOM
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const loginModal = document.getElementById('loginModal');
const registerModal = document.getElementById('registerModal');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const closeButtons = document.getElementsByClassName('close');
const userInfo = document.querySelector('.user-info');
const authButtons = document.querySelector('.auth-buttons');
const usernameSpan = document.getElementById('username');
const logoutBtn = document.getElementById('logoutBtn');

// API URL
const API_URL = '/api';

// Функции для работы с авторизацией
const auth = {
	// Сохранение токена и данных пользователя
	setAuth(token, user) {
		localStorage.setItem('token', token);
		localStorage.setItem('user', JSON.stringify(user));
		this.updateUI();
	},

	// Получение токена
	getToken() {
		return localStorage.getItem('token');
	},

	// Получение данных пользователя
	getUser() {
		const user = localStorage.getItem('user');
		return user ? JSON.parse(user) : null;
	},

	// Проверка авторизации
	isAuthenticated() {
		return !!this.getToken();
	},

	// Выход из системы
	logout() {
		localStorage.removeItem('token');
		localStorage.removeItem('user');
		this.updateUI();
		window.location.href = '/';
	},

	// Обновление UI в зависимости от состояния авторизации
	updateUI() {
		const authButtons = document.getElementById('authButtons');
		const userInfo = document.getElementById('userInfo');
		const user = this.getUser();

		if (this.isAuthenticated() && user) {
			// Показываем информацию о пользователе
			authButtons.style.display = 'none';
			userInfo.style.display = 'flex';
			document.getElementById('username').textContent = user.username;

			// Обновляем статистику
			this.updateUserStats();
		} else {
			// Показываем кнопки входа/регистрации
			authButtons.style.display = 'flex';
			userInfo.style.display = 'none';
		}
	},

	// Обновление статистики пользователя
	async updateUserStats() {
		try {
			const response = await fetch('/api/auth/me', {
				headers: {
					'Authorization': `Bearer ${this.getToken()}`
				}
			});

			if (response.ok) {
				const userData = await response.json();
				// Обновляем статистику на странице
				document.getElementById('gamesPlayed').textContent = userData.stats.gamesPlayed;
				document.getElementById('gamesWon').textContent = userData.stats.gamesWon;
				document.getElementById('bestTime').textContent =
					userData.stats.bestTime ? `${userData.stats.bestTime} сек` : 'Нет';

				// Обновляем достижения
				this.updateAchievements(userData.achievements);
			}
		} catch (error) {
			console.error('Ошибка при получении статистики:', error);
		}
	},

	// Обновление списка достижений
	updateAchievements(achievements) {
		const achievementsList = document.getElementById('achievementsList');
		if (!achievementsList) return;

		achievementsList.innerHTML = achievements.map(achievement => `
			<div class="achievement">
				<span class="achievement-icon">${achievement.achievement.icon}</span>
				<div class="achievement-info">
					<h4>${achievement.achievement.name}</h4>
					<p>${achievement.achievement.description}</p>
				</div>
				<span class="achievement-date">
					${new Date(achievement.dateEarned).toLocaleDateString()}
				</span>
			</div>
		`).join('');
	}
};

// Функции для работы с модальными окнами
const openModal = (modal) => {
	modal.style.display = 'block';
};

const closeModal = (modal) => {
	modal.style.display = 'none';
};

// Обработчики событий для модальных окон
loginBtn.addEventListener('click', () => openModal(loginModal));
registerBtn.addEventListener('click', () => openModal(registerModal));

Array.from(closeButtons).forEach(button => {
	button.addEventListener('click', () => {
		closeModal(loginModal);
		closeModal(registerModal);
	});
});

window.addEventListener('click', (event) => {
	if (event.target === loginModal) closeModal(loginModal);
	if (event.target === registerModal) closeModal(registerModal);
});

// Функция для отображения ошибок
const showError = (message) => {
	alert(message); // В реальном приложении здесь должно быть более красивое уведомление
};

// Обработчики форм
document.addEventListener('DOMContentLoaded', () => {
	// Форма регистрации
	const registerForm = document.getElementById('registerForm');
	if (registerForm) {
		registerForm.addEventListener('submit', async (e) => {
			e.preventDefault();
			const formData = new FormData(registerForm);

			try {
				const response = await fetch('/api/auth/register', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({
						username: formData.get('username'),
						email: formData.get('email'),
						password: formData.get('password')
					})
				});

				const data = await response.json();

				if (response.ok) {
					auth.setAuth(data.token, data.user);
					window.location.href = '/game.html';
				} else {
					alert(data.message);
				}
			} catch (error) {
				alert('Ошибка при регистрации');
			}
		});
	}

	// Форма входа
	const loginForm = document.getElementById('loginForm');
	if (loginForm) {
		loginForm.addEventListener('submit', async (e) => {
			e.preventDefault();
			const formData = new FormData(loginForm);

			try {
				const response = await fetch('/api/auth/login', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({
						email: formData.get('email'),
						password: formData.get('password')
					})
				});

				const data = await response.json();

				if (response.ok) {
					auth.setAuth(data.token, data.user);
					window.location.href = '/game.html';
				} else {
					alert(data.message);
				}
			} catch (error) {
				alert('Ошибка при входе');
			}
		});
	}

	// Кнопка выхода
	const logoutButton = document.getElementById('logoutButton');
	if (logoutButton) {
		logoutButton.addEventListener('click', () => {
			auth.logout();
		});
	}

	// Проверяем состояние авторизации при загрузке страницы
	auth.updateUI();
}); 