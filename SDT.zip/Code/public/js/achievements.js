// API URL
const API_URL = '/api';

// Элементы DOM
const achievementsList = document.getElementById('achievements-list');
const achievementsEarned = document.getElementById('achievements-earned');
const achievementsTotal = document.getElementById('achievements-total');
const achievementsProgress = document.getElementById('achievements-progress');
const filterButtons = document.querySelectorAll('.filter-button');
const achievementModal = document.getElementById('achievementModal');
const closeButtons = document.getElementsByClassName('close');

// Текущий фильтр
let currentFilter = 'all';

// Функция для получения токена
const getAuthToken = () => localStorage.getItem('token');

// Функция для форматирования даты
const formatDate = (dateString) => {
	const date = new Date(dateString);
	return date.toLocaleDateString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric'
	});
};

// Функция для создания карточки достижения
const createAchievementCard = (achievement) => {
	const card = document.createElement('div');
	card.className = `achievement-card ${!achievement.earned ? 'locked' : ''}`;

	card.innerHTML = `
        <img class="achievement-icon" src="${achievement.icon}" alt="${achievement.name}">
        <div class="achievement-name">${achievement.name}</div>
        <div class="achievement-type ${achievement.type}">${achievement.type}</div>
        <div class="achievement-description">${achievement.description}</div>
        ${achievement.earned ? `
            <div class="achievement-date">Получено: ${formatDate(achievement.dateEarned)}</div>
        ` : ''}
    `;

	card.addEventListener('click', () => showAchievementDetails(achievement));

	return card;
};

// Функция для отображения деталей достижения
const showAchievementDetails = (achievement) => {
	document.getElementById('achievement-icon').src = achievement.icon;
	document.getElementById('achievement-name').textContent = achievement.name;
	document.getElementById('achievement-type').textContent = achievement.type;
	document.getElementById('achievement-type').className = `achievement-type ${achievement.type}`;
	document.getElementById('achievement-description').textContent = achievement.description;
	document.getElementById('achievement-earned-by').textContent = `${achievement.earnedBy} игроков`;
	document.getElementById('achievement-date').textContent = achievement.earned ?
		formatDate(achievement.dateEarned) : 'Не получено';

	achievementModal.style.display = 'block';
};

// Функция для обновления статистики достижений
const updateAchievementsStats = (achievements) => {
	const earned = achievements.filter(a => a.earned).length;
	const total = achievements.length;
	const progress = Math.round((earned / total) * 100);

	achievementsEarned.textContent = earned;
	achievementsTotal.textContent = total;
	achievementsProgress.textContent = `${progress}%`;
};

// Функция для загрузки достижений
const loadAchievements = async (type = 'all') => {
	try {
		const token = getAuthToken();
		if (!token) {
			achievementsList.innerHTML = '<p class="error-message">Для просмотра достижений необходимо авторизоваться</p>';
			return;
		}

		const url = type === 'all' ?
			`${API_URL}/achievements` :
			`${API_URL}/achievements/filter/${type}`;

		const response = await fetch(url, {
			headers: {
				'Authorization': `Bearer ${token}`
			}
		});

		if (response.ok) {
			const achievements = await response.json();

			// Очищаем список
			achievementsList.innerHTML = '';

			// Добавляем карточки достижений
			achievements.forEach(achievement => {
				achievementsList.appendChild(createAchievementCard(achievement));
			});

			// Обновляем статистику
			updateAchievementsStats(achievements);
		} else {
			const error = await response.json();
			throw new Error(error.message);
		}
	} catch (error) {
		console.error('Ошибка при загрузке достижений:', error);
		achievementsList.innerHTML = `<p class="error-message">Ошибка при загрузке достижений: ${error.message}</p>`;
	}
};

// Обработчики событий для фильтров
filterButtons.forEach(button => {
	button.addEventListener('click', () => {
		// Убираем активный класс у всех кнопок
		filterButtons.forEach(btn => btn.classList.remove('active'));
		// Добавляем активный класс нажатой кнопке
		button.classList.add('active');

		// Обновляем текущий фильтр и загружаем достижения
		currentFilter = button.dataset.type;
		loadAchievements(currentFilter);
	});
});

// Обработчики для модального окна
Array.from(closeButtons).forEach(button => {
	button.addEventListener('click', () => {
		achievementModal.style.display = 'none';
	});
});

window.addEventListener('click', (event) => {
	if (event.target === achievementModal) {
		achievementModal.style.display = 'none';
	}
});

// Загружаем достижения при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
	loadAchievements();
}); 