const mongoose = require('mongoose');
require('dotenv').config();

// Подключение к MongoDB
mongoose.connect(process.env.MONGODB_URI, {
	useNewUrlParser: true,
	useUnifiedTopology: true
});

// Схемы
const userSchema = new mongoose.Schema({
	username: {
		type: String,
		required: true,
		unique: true,
		trim: true,
		minlength: 3,
		maxlength: 30
	},
	email: {
		type: String,
		required: true,
		unique: true,
		trim: true,
		lowercase: true
	},
	password: {
		type: String,
		required: true,
		minlength: 6
	},
	stats: {
		gamesPlayed: { type: Number, default: 0 },
		gamesWon: { type: Number, default: 0 },
		totalTime: { type: Number, default: 0 },
		bestTime: { type: Number, default: null }
	},
	createdAt: {
		type: Date,
		default: Date.now
	}
});

const gameSchema = new mongoose.Schema({
	user: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'User',
		required: true
	},
	difficulty: {
		type: String,
		enum: ['easy', 'medium', 'hard'],
		required: true
	},
	startTime: {
		type: Date,
		required: true
	},
	endTime: {
		type: Date
	},
	duration: {
		type: Number
	},
	result: {
		type: String,
		enum: ['victory', 'defeat', 'in_progress'],
		default: 'in_progress'
	},
	board: {
		size: {
			width: Number,
			height: Number
		},
		mines: [[Boolean]],
		revealed: [[Boolean]],
		flagged: [[Boolean]]
	}
});

const achievementSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
		unique: true
	},
	description: {
		type: String,
		required: true
	},
	icon: {
		type: String,
		required: true
	},
	conditions: {
		type: Map,
		of: Number,
		required: true
	},
	earnedBy: {
		type: Number,
		default: 0
	},
	rarity: {
		type: String,
		enum: ['common', 'rare', 'epic', 'legendary'],
		default: 'common'
	}
});

// Модели
const User = mongoose.model('User', userSchema);
const Game = mongoose.model('Game', gameSchema);
const Achievement = mongoose.model('Achievement', achievementSchema);

// Функция для инициализации базы данных
async function initializeDatabase() {
	try {
		// Очистка существующих коллекций
		await User.deleteMany({});
		await Game.deleteMany({});
		await Achievement.deleteMany({});

		// Создание тестового пользователя
		const testUser = await User.create({
			username: 'testuser',
			email: 'test@example.com',
			password: 'password123'
		});

		// Создание достижений
		const achievements = await Achievement.create([
			{
				name: 'Первая победа',
				description: 'Выиграйте свою первую игру',
				icon: '🏆',
				conditions: new Map([
					['gamesWon', 1]
				]),
				rarity: 'common'
			},
			{
				name: 'Мастер сапера',
				description: 'Выиграйте 10 игр',
				icon: '👑',
				conditions: new Map([
					['gamesWon', 10]
				]),
				rarity: 'rare'
			},
			{
				name: 'Скоростной игрок',
				description: 'Выиграйте игру менее чем за 60 секунд',
				icon: '⚡',
				conditions: new Map([
					['bestTime', 60]
				]),
				rarity: 'epic'
			}
		]);

		// Создание тестовой игры
		const testGame = await Game.create({
			user: testUser._id,
			difficulty: 'easy',
			startTime: new Date(),
			board: {
				size: { width: 9, height: 9 },
				mines: Array(9).fill().map(() => Array(9).fill(false)),
				revealed: Array(9).fill().map(() => Array(9).fill(false)),
				flagged: Array(9).fill().map(() => Array(9).fill(false))
			}
		});

		console.log('База данных успешно инициализирована!');
		console.log('Создан тестовый пользователь:', testUser.username);
		console.log('Создано достижений:', achievements.length);
		console.log('Создана тестовая игра');

	} catch (error) {
		console.error('Ошибка при инициализации базы данных:', error);
	} finally {
		mongoose.disconnect();
	}
}

// Запуск инициализации
initializeDatabase(); 