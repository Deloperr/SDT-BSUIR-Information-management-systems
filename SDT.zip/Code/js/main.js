class Game {
	constructor() {
		this.difficulty = 'easy';
		this.boardSize = 9;
		this.mineCount = 10;
		this.board = [];
		this.revealedCount = 0;
		this.gameOver = false;
		this.timer = 0;
		this.timerInterval = null;
	}

	init() {
		// Инициализация обработчиков событий
		document.querySelectorAll('.difficulty-btn').forEach(btn => {
			btn.addEventListener('click', () => {
				// Убираем активный класс у всех кнопок
				document.querySelectorAll('.difficulty-btn').forEach(b => b.classList.remove('active'));
				// Добавляем активный класс нажатой кнопке
				btn.classList.add('active');
				this.setDifficulty(btn.dataset.difficulty);
			});
		});

		// Обработчик кнопки новой игры
		document.getElementById('new-game-btn').addEventListener('click', () => {
			this.initializeBoard();
		});

		// Обработчик кнопки помощи
		document.getElementById('help-btn').addEventListener('click', () => {
			const helpText = `
Правила игры "Сапер":

1. Управление:
   - ЛКМ (левая кнопка мыши) - открыть клетку
   - ПКМ (правая кнопка мыши) - поставить/убрать флаг

2. Игровое поле:
   - Числа показывают количество мин вокруг клетки
   - Пустая клетка автоматически открывает соседние пустые клетки
   - Флаг отмечает предполагаемое место мины

3. Уровни сложности:
   - Легкий: поле 9x9, 10 мин
   - Средний: поле 16x16, 40 мин
   - Сложный: поле 30x30, 99 мин

4. Цель игры:
   - Открыть все клетки, не содержащие мин
   - Правильно отметить все мины флагами

5. Подсказки:
   - Начинайте с углов и краев поля
   - Используйте логику для определения мест мин
   - Внимательно следите за числами

Удачи в игре! 🎮
			`;
			alert(helpText);
		});

		// Инициализация игры
		this.initializeBoard();
	}

	setDifficulty(difficulty) {
		this.difficulty = difficulty;
		switch (difficulty) {
			case 'easy':
				this.boardSize = 9;
				this.mineCount = 10;
				break;
			case 'medium':
				this.boardSize = 16;
				this.mineCount = 40;
				break;
			case 'hard':
				this.boardSize = 30;
				this.mineCount = 99;
				break;
		}
		this.initializeBoard();
	}

	initializeBoard() {
		// Очищаем поле
		const gameBoard = document.getElementById('game-board');
		gameBoard.innerHTML = '';
		gameBoard.style.gridTemplateColumns = `repeat(${this.boardSize}, 30px)`;
		gameBoard.style.gridTemplateRows = `repeat(${this.boardSize}, 30px)`;

		// Создаем пустое поле
		this.board = Array(this.boardSize).fill().map(() => Array(this.boardSize).fill(0));

		// Расставляем мины
		let minesPlaced = 0;
		while (minesPlaced < this.mineCount) {
			const x = Math.floor(Math.random() * this.boardSize);
			const y = Math.floor(Math.random() * this.boardSize);

			if (this.board[y][x] !== -1) {
				this.board[y][x] = -1; // -1 означает мину
				minesPlaced++;

				// Увеличиваем счетчики вокруг мины
				for (let dy = -1; dy <= 1; dy++) {
					for (let dx = -1; dx <= 1; dx++) {
						const nx = x + dx;
						const ny = y + dy;

						if (nx >= 0 && nx < this.boardSize && ny >= 0 && ny < this.boardSize && this.board[ny][nx] !== -1) {
							this.board[ny][nx]++;
						}
					}
				}
			}
		}

		// Создаем клетки на поле
		for (let y = 0; y < this.boardSize; y++) {
			for (let x = 0; x < this.boardSize; x++) {
				const cell = document.createElement('div');
				cell.className = 'cell';
				cell.dataset.x = x;
				cell.dataset.y = y;

				cell.addEventListener('click', () => this.handleCellClick(x, y));
				cell.addEventListener('contextmenu', (e) => {
					e.preventDefault();
					this.handleRightClick(x, y);
				});

				gameBoard.appendChild(cell);
			}
		}

		// Сброс состояния игры
		this.revealedCount = 0;
		this.gameOver = false;
		document.getElementById('game-status').textContent = '';
		document.getElementById('mines-count').textContent = this.mineCount;

		// Сброс и запуск таймера
		clearInterval(this.timerInterval);
		this.timer = 0;
		this.updateTimer();
		this.timerInterval = setInterval(() => {
			this.timer++;
			this.updateTimer();
		}, 1000);
	}

	updateTimer() {
		const minutes = Math.floor(this.timer / 60).toString().padStart(2, '0');
		const seconds = (this.timer % 60).toString().padStart(2, '0');
		document.getElementById('game-timer').textContent = `${minutes}:${seconds}`;
	}

	handleCellClick(x, y) {
		if (this.gameOver) return;

		const cell = document.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
		if (cell.classList.contains('revealed') || cell.classList.contains('flag')) return;

		if (this.board[y][x] === -1) {
			// Игрок наступил на мину
			this.revealAllMines();
			cell.classList.add('mine');
			this.gameOver = true;
			document.getElementById('game-status').textContent = 'Вы проиграли!';
			document.getElementById('game-status').className = 'game-status defeat';
			clearInterval(this.timerInterval);
			return;
		}

		this.revealCell(x, y);

		// Проверка победы
		if (this.revealedCount === this.boardSize * this.boardSize - this.mineCount) {
			this.gameOver = true;
			document.getElementById('game-status').textContent = 'Вы победили!';
			document.getElementById('game-status').className = 'game-status victory';
			clearInterval(this.timerInterval);
			this.showAchievement();
		}
	}

	revealCell(x, y) {
		if (x < 0 || x >= this.boardSize || y < 0 || y >= this.boardSize) return;

		const cell = document.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
		if (cell.classList.contains('revealed')) return;

		cell.classList.add('revealed');
		this.revealedCount++;

		if (this.board[y][x] > 0) {
			cell.textContent = this.board[y][x];
			cell.classList.add(`cell-${this.board[y][x]}`);
		} else if (this.board[y][x] === 0) {
			// Раскрываем соседние пустые клетки
			for (let dy = -1; dy <= 1; dy++) {
				for (let dx = -1; dx <= 1; dx++) {
					if (dx !== 0 || dy !== 0) {
						this.revealCell(x + dx, y + dy);
					}
				}
			}
		}
	}

	handleRightClick(x, y) {
		if (this.gameOver) return;

		const cell = document.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
		if (cell.classList.contains('revealed')) return;

		if (cell.classList.contains('flag')) {
			cell.classList.remove('flag');
			cell.textContent = '';
			document.getElementById('mines-count').textContent = parseInt(document.getElementById('mines-count').textContent) + 1;
		} else {
			cell.classList.add('flag');
			cell.textContent = '🚩';
			document.getElementById('mines-count').textContent = parseInt(document.getElementById('mines-count').textContent) - 1;
		}
	}

	revealAllMines() {
		for (let y = 0; y < this.boardSize; y++) {
			for (let x = 0; x < this.boardSize; x++) {
				if (this.board[y][x] === -1) {
					const cell = document.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
					cell.classList.add('mine');
				}
			}
		}
	}

	showAchievement() {
		const notification = document.getElementById('achievement-notification');
		notification.style.display = 'flex';
		setTimeout(() => {
			notification.style.display = 'none';
		}, 3000);
	}
}

// Инициализация игры
const game = new Game();
game.init(); 