class Achievements {
	constructor() {
		this.achievements = [];
		this.init();
	}

	init() {
		// Проверяем авторизацию
		if (!auth.isAuthenticated) {
			this.showAuthMessage();
			return;
		}

		// Загрузка достижений
		this.loadAchievements();
	}

	showAuthMessage() {
		const container = document.querySelector('.achievements-container');
		container.innerHTML = `
			<div class="auth-message">
				<h2>Для просмотра достижений необходимо авторизоваться</h2>
				<p>Авторизуйтесь, чтобы отслеживать свой прогресс и получать достижения</p>
				<div class="auth-buttons">
					<button class="btn btn-login">Войти</button>
					<button class="btn btn-register">Регистрация</button>
				</div>
			</div>
		`;

		// Добавляем обработчики для кнопок
		container.querySelector('.btn-login').addEventListener('click', () => auth.showLoginModal());
		container.querySelector('.btn-register').addEventListener('click', () => auth.showRegisterModal());
	}

	async loadAchievements() {
		try {
			// Здесь будет запрос к API
			const response = await this.fetchAchievements();
			this.achievements = response.achievements;
			this.updateUI();
		} catch (error) {
			console.error('Ошибка при загрузке достижений:', error);
		}
	}

	async fetchAchievements() {
		// Здесь будет реальный запрос к API
		return new Promise((resolve) => {
			setTimeout(() => {
				resolve({
					achievements: [
						{
							id: 1,
							title: 'Первая победа',
							description: 'Выиграть свою первую игру в Сапёра',
							type: 'common',
							date: '15.10.2023',
							status: 'completed'
						},
						{
							id: 2,
							title: 'Без единой ошибки',
							description: 'Победить, не поставив ни одного неправильного флага',
							type: 'rare',
							date: '02.11.2023',
							status: 'completed'
						},
						{
							id: 3,
							title: 'Новичок',
							description: 'Завершить 10 игр в любом режиме',
							type: 'common',
							date: '20.11.2023',
							status: 'completed'
						},
						{
							id: 4,
							title: 'Скоростной сапер',
							description: 'Победить на среднем уровне менее чем за 1 минуту',
							type: 'rare',
							progress: 80,
							progressText: 'Лучшее время: 1 мин 15 сек',
							status: 'in_progress'
						},
						{
							id: 5,
							title: 'Мастер флагов',
							description: 'Поставить 100 флагов в играх',
							type: 'common',
							progress: 67,
							progressText: '67/100 флагов',
							status: 'in_progress'
						},
						{
							id: 6,
							title: 'Эксперт по минам',
							description: 'Победить на сложном уровне за менее чем 3 минуты',
							type: 'epic',
							status: 'locked'
						},
						{
							id: 7,
							title: 'Легенда Сапёра',
							description: 'Выиграть 100 игр на сложном уровне',
							type: 'epic',
							status: 'locked'
						}
					]
				});
			}, 1000);
		});
	}

	updateUI() {
		// Обновление статистики пользователя
		const completedCount = this.achievements.filter(a => a.status === 'completed').length;
		const totalCount = this.achievements.length;
		document.querySelector('.stat-item:first-child span:last-child').textContent =
			`${completedCount}/${totalCount} достижений`;

		// Обновление списка достижений
		this.updateAchievementsList('completed', 'Полученные достижения');
		this.updateAchievementsList('in_progress', 'Доступные для получения');
		this.updateAchievementsList('locked', 'Еще не доступно');
	}

	updateAchievementsList(status, title) {
		const section = document.querySelector(`.section-title:contains('${title}')`).nextElementSibling;
		section.innerHTML = '';

		const filteredAchievements = this.achievements.filter(a => a.status === status);
		filteredAchievements.forEach(achievement => {
			const card = this.createAchievementCard(achievement);
			section.appendChild(card);
		});
	}

	createAchievementCard(achievement) {
		const card = document.createElement('div');
		card.className = `achievement-card ${achievement.status === 'locked' ? 'achievement-locked' : ''}`;

		let html = `
            <div class="achievement-header">
                <div class="achievement-title">${achievement.title}</div>
                <div class="achievement-badge badge-${achievement.type}">${this.getBadgeIcon(achievement.type)}</div>
            </div>
            <div class="achievement-description">
                ${achievement.description}
            </div>
        `;

		if (achievement.status === 'completed') {
			html += `
                <div class="achievement-date">
                    Получено: ${achievement.date}
                </div>
            `;
		} else if (achievement.status === 'in_progress') {
			html += `
                <div class="achievement-progress">
                    <div class="progress-text">${achievement.progressText}</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${achievement.progress}%"></div>
                    </div>
                </div>
            `;
		} else if (achievement.status === 'locked') {
			html += `
                <div class="locked-overlay">Заблокировано</div>
            `;
		}

		card.innerHTML = html;
		return card;
	}

	getBadgeIcon(type) {
		const icons = {
			common: '🏆',
			rare: '✨',
			epic: '💎'
		};
		return icons[type] || '🏆';
	}
}

// Инициализация достижений
const achievements = new Achievements(); 