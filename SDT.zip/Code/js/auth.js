class Auth {
	constructor() {
		this.isAuthenticated = false;
		this.currentUser = null;
		this.init();
	}

	init() {
		// Инициализация обработчиков событий
		document.querySelector('.btn-login').addEventListener('click', () => this.showLoginModal());
		document.querySelector('.btn-register').addEventListener('click', () => this.showRegisterModal());

		// Обработка форм
		document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
		document.getElementById('registerForm').addEventListener('submit', (e) => this.handleRegister(e));

		// Закрытие модальных окон
		document.querySelectorAll('.modal').forEach(modal => {
			modal.addEventListener('click', (e) => {
				if (e.target === modal) {
					this.hideModal(modal);
				}
			});
		});
	}

	showLoginModal() {
		document.getElementById('loginModal').style.display = 'flex';
	}

	showRegisterModal() {
		document.getElementById('registerModal').style.display = 'flex';
	}

	hideModal(modal) {
		modal.style.display = 'none';
	}

	async handleLogin(e) {
		e.preventDefault();
		const email = document.getElementById('loginEmail').value;
		const password = document.getElementById('loginPassword').value;

		try {
			// Здесь будет запрос к API
			const response = await this.login(email, password);
			if (response.success) {
				this.isAuthenticated = true;
				this.currentUser = response.user;
				this.updateUI();
				this.hideModal(document.getElementById('loginModal'));
			} else {
				alert('Ошибка входа: ' + response.message);
			}
		} catch (error) {
			alert('Ошибка при входе: ' + error.message);
		}
	}

	async handleRegister(e) {
		e.preventDefault();
		const username = document.getElementById('registerUsername').value;
		const email = document.getElementById('registerEmail').value;
		const password = document.getElementById('registerPassword').value;
		const passwordConfirm = document.getElementById('registerPasswordConfirm').value;

		if (password !== passwordConfirm) {
			alert('Пароли не совпадают');
			return;
		}

		try {
			// Здесь будет запрос к API
			const response = await this.register(username, email, password);
			if (response.success) {
				alert('Регистрация успешна! Теперь вы можете войти.');
				this.hideModal(document.getElementById('registerModal'));
				this.showLoginModal();
			} else {
				alert('Ошибка регистрации: ' + response.message);
			}
		} catch (error) {
			alert('Ошибка при регистрации: ' + error.message);
		}
	}

	async login(email, password) {
		// Здесь будет реальный запрос к API
		return new Promise((resolve) => {
			setTimeout(() => {
				resolve({
					success: true,
					user: {
						id: 1,
						username: 'TestUser',
						email: email
					}
				});
			}, 1000);
		});
	}

	async register(username, email, password) {
		// Здесь будет реальный запрос к API
		return new Promise((resolve) => {
			setTimeout(() => {
				resolve({
					success: true,
					message: 'Регистрация успешна'
				});
			}, 1000);
		});
	}

	updateUI() {
		const authButtons = document.querySelector('.auth-buttons');
		if (this.isAuthenticated) {
			authButtons.innerHTML = `
                <span class="user-info">Привет, ${this.currentUser.username}</span>
                <button class="btn btn-logout">Выйти</button>
            `;
			document.querySelector('.btn-logout').addEventListener('click', () => this.logout());
		} else {
			authButtons.innerHTML = `
                <button class="btn btn-login">Войти</button>
                <button class="btn btn-register">Регистрация</button>
            `;
		}
	}

	logout() {
		this.isAuthenticated = false;
		this.currentUser = null;
		this.updateUI();
	}
}

// Инициализация авторизации
const auth = new Auth(); 