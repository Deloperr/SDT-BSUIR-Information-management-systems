class Leaderboard {
	constructor() {
		this.currentPage = 1;
		this.itemsPerPage = 10;
		this.totalPages = 1;
		this.difficulty = 'all';
		this.timeFilter = 'all';
		this.init();
	}

	init() {
		// Проверяем авторизацию
		if (!auth.isAuthenticated) {
			this.showAuthMessage();
			return;
		}

		// Инициализация обработчиков событий
		document.getElementById('difficulty-filter').addEventListener('change', (e) => {
			this.difficulty = e.target.value;
			this.loadLeaderboard();
		});

		document.getElementById('time-filter').addEventListener('change', (e) => {
			this.timeFilter = e.target.value;
			this.loadLeaderboard();
		});

		document.querySelectorAll('.pagination-btn').forEach(btn => {
			btn.addEventListener('click', () => {
				if (btn.textContent === '←') {
					this.currentPage--;
				} else {
					this.currentPage++;
				}
				this.loadLeaderboard();
			});
		});

		// Загрузка начальных данных
		this.loadLeaderboard();
	}

	showAuthMessage() {
		const container = document.querySelector('.leaderboard-container');
		container.innerHTML = `
			<div class="auth-message">
				<h2>Для просмотра таблицы лидеров необходимо авторизоваться</h2>
				<div class="auth-buttons">
					<button class="btn btn-login">Войти</button>
					<button class="btn btn-register">Регистрация</button>
				</div>
			</div>
		`;

		// Добавляем обработчики для кнопок
		container.querySelector('.btn-login').addEventListener('click', () => auth.showLoginModal());
		container.querySelector('.btn-register').addEventListener('click', () => auth.showRegisterModal());
	}

	async loadLeaderboard() {
		try {
			// Здесь будет запрос к API
			const response = await this.fetchLeaderboard();
			this.totalPages = Math.ceil(response.total / this.itemsPerPage);
			this.updateUI(response.leaderboard);
		} catch (error) {
			console.error('Ошибка при загрузке таблицы лидеров:', error);
		}
	}

	async fetchLeaderboard() {
		// Здесь будет реальный запрос к API
		return new Promise((resolve) => {
			setTimeout(() => {
				resolve({
					total: 100,
					leaderboard: [
						{
							place: 1,
							player: {
								name: 'PlayerOne',
								avatar: 'P'
							},
							difficulty: 'Сложная',
							time: '2:45',
							date: '15.12.2023'
						},
						{
							place: 2,
							player: {
								name: 'MinerPro',
								avatar: 'M'
							},
							difficulty: 'Сложная',
							time: '3:12',
							date: '14.12.2023'
						},
						{
							place: 3,
							player: {
								name: 'Sapper2023',
								avatar: 'S'
							},
							difficulty: 'Средняя',
							time: '1:45',
							date: '13.12.2023'
						},
						{
							place: 4,
							player: {
								name: 'ExpertMiner',
								avatar: 'E'
							},
							difficulty: 'Сложная',
							time: '3:30',
							date: '12.12.2023'
						},
						{
							place: 5,
							player: {
								name: 'NewPlayer',
								avatar: 'N'
							},
							difficulty: 'Легкая',
							time: '0:45',
							date: '11.12.2023'
						}
					]
				});
			}, 1000);
		});
	}

	updateUI(leaderboard) {
		const tbody = document.querySelector('.leaderboard-table tbody');
		tbody.innerHTML = '';

		leaderboard.forEach(entry => {
			const tr = document.createElement('tr');
			if (entry.place === 1) {
				tr.classList.add('top-player');
			}

			tr.innerHTML = `
                <td>${entry.place}</td>
                <td>
                    <div class="player-info">
                        <div class="player-avatar">${entry.player.avatar}</div>
                        <div class="player-name">${entry.player.name}</div>
                    </div>
                </td>
                <td>${entry.difficulty}</td>
                <td>${entry.time}</td>
                <td>${entry.date}</td>
            `;

			tbody.appendChild(tr);
		});

		// Обновление пагинации
		this.updatePagination();
	}

	updatePagination() {
		const prevBtn = document.querySelector('.pagination-btn:first-child');
		const nextBtn = document.querySelector('.pagination-btn:last-child');
		const info = document.querySelector('.pagination-info');

		prevBtn.disabled = this.currentPage === 1;
		nextBtn.disabled = this.currentPage === this.totalPages;
		info.textContent = `Страница ${this.currentPage} из ${this.totalPages}`;
	}
}

// Инициализация таблицы лидеров
const leaderboard = new Leaderboard(); 