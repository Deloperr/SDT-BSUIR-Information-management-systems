const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
	try {
		// Получение токена из заголовка
		const token = req.header('Authorization')?.replace('Bearer ', '');

		if (!token) {
			return res.status(401).json({ message: 'Требуется авторизация' });
		}

		// Проверка токена
		const decoded = jwt.verify(token, process.env.JWT_SECRET);
		req.user = { userId: decoded.userId };
		next();
	} catch (error) {
		res.status(401).json({ message: 'Неверный токен авторизации' });
	}
}; 