const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const User = require('../models/User');
const Game = require('../models/Game');
const Achievement = require('../models/Achievement');

// Получить список всех пользователей
router.get('/users', [auth, admin], async (req, res) => {
	try {
		const users = await User.find()
			.select('-password')
			.populate('achievements.achievement');
		res.json(users);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получить детальную информацию о пользователе
router.get('/users/:userId', [auth, admin], async (req, res) => {
	try {
		const user = await User.findById(req.params.userId)
			.select('-password')
			.populate('achievements.achievement');

		if (!user) {
			return res.status(404).json({ message: 'Пользователь не найден' });
		}

		const games = await Game.find({ user: req.params.userId })
			.sort({ startTime: -1 });

		res.json({
			user,
			games
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Блокировка/разблокировка пользователя
router.patch('/users/:userId/status', [auth, admin], async (req, res) => {
	try {
		const { status } = req.body;
		const user = await User.findById(req.params.userId);

		if (!user) {
			return res.status(404).json({ message: 'Пользователь не найден' });
		}

		user.status = status;
		await user.save();

		res.json({ message: 'Статус пользователя обновлен', user });
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Удаление пользователя
router.delete('/users/:userId', [auth, admin], async (req, res) => {
	try {
		const user = await User.findById(req.params.userId);

		if (!user) {
			return res.status(404).json({ message: 'Пользователь не найден' });
		}

		// Удаление всех игр пользователя
		await Game.deleteMany({ user: req.params.userId });

		// Обновление статистики достижений
		for (const achievementData of user.achievements) {
			const achievement = await Achievement.findById(achievementData.achievement);
			if (achievement) {
				achievement.earnedBy = Math.max(0, achievement.earnedBy - 1);
				await achievement.save();
			}
		}

		await user.remove();

		res.json({ message: 'Пользователь удален' });
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Управление достижениями
router.post('/achievements', [auth, admin], async (req, res) => {
	try {
		const achievement = new Achievement(req.body);
		await achievement.save();
		res.status(201).json(achievement);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

router.patch('/achievements/:id', [auth, admin], async (req, res) => {
	try {
		const achievement = await Achievement.findByIdAndUpdate(
			req.params.id,
			req.body,
			{ new: true }
		);

		if (!achievement) {
			return res.status(404).json({ message: 'Достижение не найдено' });
		}

		res.json(achievement);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

router.delete('/achievements/:id', [auth, admin], async (req, res) => {
	try {
		const achievement = await Achievement.findById(req.params.id);

		if (!achievement) {
			return res.status(404).json({ message: 'Достижение не найдено' });
		}

		// Удаление достижения у всех пользователей
		await User.updateMany(
			{ 'achievements.achievement': req.params.id },
			{ $pull: { achievements: { achievement: req.params.id } } }
		);

		await achievement.remove();

		res.json({ message: 'Достижение удалено' });
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получить детальную информацию об игре
router.get('/games/:gameId', [auth, admin], async (req, res) => {
	try {
		const game = await Game.findById(req.params.gameId)
			.populate('user', '-password');

		if (!game) {
			return res.status(404).json({ message: 'Игра не найдена' });
		}

		res.json(game);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Удаление игры
router.delete('/games/:gameId', [auth, admin], async (req, res) => {
	try {
		const game = await Game.findById(req.params.gameId);

		if (!game) {
			return res.status(404).json({ message: 'Игра не найдена' });
		}

		// Обновление статистики пользователя
		const user = await User.findById(game.user);
		if (user) {
			user.stats.gamesPlayed--;
			if (game.result === 'victory') {
				user.stats.gamesWon--;
			}
			user.stats.totalTime -= game.duration || 0;
			await user.save();
		}

		await game.remove();

		res.json({ message: 'Игра удалена' });
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

module.exports = router; 