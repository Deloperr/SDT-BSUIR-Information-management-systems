const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Achievement = require('../models/Achievement');
const User = require('../models/User');

// Получить все достижения
router.get('/', auth, async (req, res) => {
	try {
		const achievements = await Achievement.find();
		const user = await User.findById(req.user.userId)
			.populate('achievements.achievement');

		const formattedAchievements = achievements.map(achievement => {
			const userAchievement = user.achievements.find(
				a => a.achievement._id.toString() === achievement._id.toString()
			);

			return {
				...achievement.toObject(),
				earned: !!userAchievement,
				dateEarned: userAchievement ? userAchievement.dateEarned : null
			};
		});

		res.json(formattedAchievements);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получить достижения пользователя
router.get('/user', auth, async (req, res) => {
	try {
		const user = await User.findById(req.user.userId)
			.populate('achievements.achievement');

		const achievements = user.achievements.map(a => ({
			...a.achievement.toObject(),
			dateEarned: a.dateEarned
		}));

		res.json(achievements);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получить конкретное достижение
router.get('/:id', auth, async (req, res) => {
	try {
		const achievement = await Achievement.findById(req.params.id);
		if (!achievement) {
			return res.status(404).json({ message: 'Достижение не найдено' });
		}

		const user = await User.findById(req.user.userId);
		const userAchievement = user.achievements.find(
			a => a.achievement.toString() === achievement._id.toString()
		);

		res.json({
			...achievement.toObject(),
			earned: !!userAchievement,
			dateEarned: userAchievement ? userAchievement.dateEarned : null
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Фильтрация достижений
router.get('/filter/:type', auth, async (req, res) => {
	try {
		const { type } = req.params;
		const query = type === 'all' ? {} : { type };

		const achievements = await Achievement.find(query);
		const user = await User.findById(req.user.userId)
			.populate('achievements.achievement');

		const formattedAchievements = achievements.map(achievement => {
			const userAchievement = user.achievements.find(
				a => a.achievement._id.toString() === achievement._id.toString()
			);

			return {
				...achievement.toObject(),
				earned: !!userAchievement,
				dateEarned: userAchievement ? userAchievement.dateEarned : null
			};
		});

		res.json(formattedAchievements);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

module.exports = router; 