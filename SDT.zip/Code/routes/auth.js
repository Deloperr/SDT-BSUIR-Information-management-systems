const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const auth = require('../middleware/auth');

// Регистрация нового пользователя
router.post('/register', async (req, res) => {
	try {
		const { username, email, password } = req.body;

		// Проверка существования пользователя
		const existingUser = await User.findOne({
			$or: [{ email }, { username }]
		});

		if (existingUser) {
			return res.status(400).json({
				message: 'Пользователь с таким email или именем уже существует'
			});
		}

		// Создание нового пользователя
		const user = new User({
			username,
			email,
			password
		});

		await user.save();

		// Создание JWT токена
		const token = jwt.sign(
			{ userId: user._id },
			process.env.JWT_SECRET,
			{ expiresIn: '24h' }
		);

		res.status(201).json({
			token,
			user: {
				id: user._id,
				username: user.username,
				email: user.email
			}
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Вход пользователя
router.post('/login', async (req, res) => {
	try {
		const { email, password } = req.body;

		// Поиск пользователя
		const user = await User.findOne({ email });
		if (!user) {
			return res.status(400).json({ message: 'Неверный email или пароль' });
		}

		// Проверка пароля
		const isMatch = await user.comparePassword(password);
		if (!isMatch) {
			return res.status(400).json({ message: 'Неверный email или пароль' });
		}

		// Создание JWT токена
		const token = jwt.sign(
			{ userId: user._id },
			process.env.JWT_SECRET,
			{ expiresIn: '24h' }
		);

		res.json({
			token,
			user: {
				id: user._id,
				username: user.username,
				email: user.email
			}
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получение информации о текущем пользователе
router.get('/me', auth, async (req, res) => {
	try {
		const user = await User.findById(req.user.userId)
			.select('-password')
			.populate('achievements.achievement');

		if (!user) {
			return res.status(404).json({ message: 'Пользователь не найден' });
		}

		res.json(user);
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

module.exports = router; 