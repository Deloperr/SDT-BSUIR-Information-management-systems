const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Game = require('../models/Game');
const User = require('../models/User');
const Achievement = require('../models/Achievement');

// Начать новую игру
router.post('/start', auth, async (req, res) => {
	try {
		const { difficulty } = req.body;

		let size = {
			width: 9,
			height: 9
		};

		// Установка размера поля в зависимости от сложности
		switch (difficulty) {
			case 'medium':
				size = { width: 16, height: 16 };
				break;
			case 'hard':
				size = { width: 16, height: 30 };
				break;
		}

		// Создание игрового поля без мин
		const board = {
			size,
			mines: Array(size.height).fill().map(() => Array(size.width).fill(false)),
			revealed: Array(size.height).fill().map(() => Array(size.width).fill(false)),
			flagged: Array(size.height).fill().map(() => Array(size.width).fill(false))
		};

		// Создание новой игры
		const game = new Game({
			user: req.user.userId,
			difficulty,
			startTime: new Date(),
			board
		});

		await game.save();

		res.json({
			gameId: game._id,
			board: {
				size,
				revealed: board.revealed,
				flagged: board.flagged
			}
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Обработка хода игрока
router.post('/:gameId/move', auth, async (req, res) => {
	try {
		const { x, y, type } = req.body;
		const game = await Game.findById(req.params.gameId);

		if (!game) {
			return res.status(404).json({ message: 'Игра не найдена' });
		}

		if (game.user.toString() !== req.user.userId) {
			return res.status(403).json({ message: 'Нет доступа к этой игре' });
		}

		// Если это первый ход, размещаем мины
		if (game.moves.length === 0 && type === 'reveal') {
			const mineCount = game.difficulty === 'easy' ? 10 : game.difficulty === 'medium' ? 40 : 99;
			let minesPlaced = 0;

			while (minesPlaced < mineCount) {
				const mineX = Math.floor(Math.random() * game.board.size.width);
				const mineY = Math.floor(Math.random() * game.board.size.height);

				// Проверяем, что мина не ставится на первую открытую клетку или рядом с ней
				if (Math.abs(mineX - x) <= 1 && Math.abs(mineY - y) <= 1) {
					continue;
				}

				if (!game.board.mines[mineY][mineX]) {
					game.board.mines[mineY][mineX] = true;
					minesPlaced++;
				}
			}
		}

		// Обработка хода
		if (type === 'reveal') {
			if (game.board.mines[y][x]) {
				game.result = 'defeat';
				game.endTime = new Date();
			} else {
				game.board.revealed[y][x] = true;
				// Проверка победы
				const totalCells = game.board.size.width * game.board.size.height;
				const revealedCount = game.board.revealed.flat().filter(Boolean).length;
				const mineCount = game.board.mines.flat().filter(Boolean).length;

				if (revealedCount === totalCells - mineCount) {
					game.result = 'victory';
					game.endTime = new Date();
				}
			}
		} else if (type === 'flag') {
			game.board.flagged[y][x] = !game.board.flagged[y][x];
		}

		// Добавляем ход в историю
		game.moves.push({ x, y, type });

		await game.save();

		// Если игра завершена, обновляем статистику пользователя
		if (game.result !== 'in_progress') {
			const user = await User.findById(req.user.userId);
			user.stats.gamesPlayed++;

			if (game.result === 'victory') {
				user.stats.gamesWon++;
				if (!user.stats.bestTime || game.duration < user.stats.bestTime) {
					user.stats.bestTime = game.duration;
				}
			}

			user.stats.totalTime += game.duration;
			await user.save();

			// Проверка достижений
			if (game.result === 'victory') {
				const achievements = await Achievement.find();
				for (const achievement of achievements) {
					if (achievement.checkConditions(user.stats, game)) {
						if (!user.achievements.find(a => a.achievement.equals(achievement._id))) {
							user.achievements.push({
								achievement: achievement._id,
								dateEarned: new Date()
							});
							achievement.earnedBy++;
							await achievement.save();
						}
					}
				}
				await user.save();
			}
		}

		res.json({
			result: game.result,
			board: {
				size: game.board.size,
				revealed: game.board.revealed,
				flagged: game.board.flagged,
				mines: game.result !== 'in_progress' ? game.board.mines : undefined
			}
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получить текущее состояние игры
router.get('/:gameId', auth, async (req, res) => {
	try {
		const game = await Game.findById(req.params.gameId);

		if (!game) {
			return res.status(404).json({ message: 'Игра не найдена' });
		}

		res.json({
			result: game.result,
			difficulty: game.difficulty,
			startTime: game.startTime,
			endTime: game.endTime,
			duration: game.duration,
			board: {
				size: game.board.size,
				revealed: game.board.revealed,
				flagged: game.board.flagged,
				mines: game.result !== 'in_progress' ? game.board.mines : undefined
			}
		});
	} catch (error) {
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

module.exports = router; 