const mongoose = require('mongoose');

const achievementSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
		unique: true
	},
	description: {
		type: String,
		required: true
	},
	icon: {
		type: String,
		required: true
	},
	conditions: {
		type: Map,
		of: Number,
		required: true
	},
	earnedBy: {
		type: Number,
		default: 0
	},
	rarity: {
		type: String,
		enum: ['common', 'rare', 'epic', 'legendary'],
		default: 'common'
	}
});

// Метод для проверки условий достижения
achievementSchema.methods.checkConditions = function (userStats, game) {
	for (const [key, value] of this.conditions) {
		switch (key) {
			case 'gamesWon':
				if (userStats.gamesWon < value) return false;
				break;
			case 'bestTime':
				if (!userStats.bestTime || userStats.bestTime > value) return false;
				break;
			case 'totalGames':
				if (userStats.gamesPlayed < value) return false;
				break;
			case 'winStreak':
				// Здесь нужно добавить логику для проверки серии побед
				break;
		}
	}
	return true;
};

module.exports = mongoose.model('Achievement', achievementSchema); 