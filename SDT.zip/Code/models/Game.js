const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
	user: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'User',
		required: true
	},
	difficulty: {
		type: String,
		enum: ['easy', 'medium', 'hard'],
		required: true
	},
	startTime: {
		type: Date,
		required: true
	},
	endTime: {
		type: Date
	},
	duration: {
		type: Number // в секундах
	},
	result: {
		type: String,
		enum: ['victory', 'defeat', 'in_progress'],
		default: 'in_progress'
	},
	moves: [{
		x: Number,
		y: Number,
		type: {
			type: String,
			enum: ['reveal', 'flag']
		},
		timestamp: {
			type: Date,
			default: Date.now
		}
	}],
	board: {
		size: {
			width: Number,
			height: Number
		},
		mines: [[{
			type: Boolean,
			default: false
		}]],
		revealed: [[{
			type: Boolean,
			default: false
		}]],
		flagged: [[{
			type: Boolean,
			default: false
		}]]
	}
});

// Вычисление длительности игры при завершении
gameSchema.pre('save', function (next) {
	if (this.endTime && this.startTime) {
		this.duration = Math.floor((this.endTime - this.startTime) / 1000);
	}
	next();
});

module.exports = mongoose.model('Game', gameSchema); 