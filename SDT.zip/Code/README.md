# Сапёр с системой достижений

Многопользовательская веб-игра "Сапёр" с системой достижений, таблицей лидеров и административной панелью.

## Функциональность

### Для игроков
- Регистрация и авторизация
- Три уровня сложности:
  - Легкий (9x9, 10 мин)
  - Средний (16x16, 40 мин)
  - Сложный (16x30, 99 мин)
- Система достижений
- Личная статистика
- История игр

### Для администраторов
- Управление пользователями
- Просмотр статистики игр
- Управление достижениями
- Модерация контента

## Технический стек

- Backend: Node.js, Express
- База данных: MongoDB
- Аутентификация: JWT
- Frontend: HTML, CSS, JavaScript

## Установка и запуск

1. Установите зависимости:
```bash
npm install
```

2. Создайте файл .env в корневой директории:
```
PORT=3000
MONGODB_URI=mongodb://localhost:27017/minesweeper
JWT_SECRET=your-super-secret-key-change-in-production
```

3. Запустите сервер:
```bash
npm start
```

Для разработки используйте:
```bash
npm run dev
```

## API Endpoints

### Аутентификация
- POST /api/auth/register - Регистрация
- POST /api/auth/login - Авторизация
- GET /api/auth/me - Данные текущего пользователя

### Игра
- POST /api/game/start - Начать новую игру
- POST /api/game/:gameId/move - Сделать ход
- GET /api/game/:gameId - Получить состояние игры

### Достижения
- GET /api/achievements - Список всех достижений
- GET /api/achievements/user - Достижения пользователя
- GET /api/achievements/:id - Информация о достижении
- GET /api/achievements/filter/:type - Фильтрация достижений

### Админ панель
- GET /api/admin/users - Список пользователей
- GET /api/admin/users/:userId - Информация о пользователе
- PATCH /api/admin/users/:userId/status - Изменение статуса пользователя
- DELETE /api/admin/users/:userId - Удаление пользователя
- POST /api/admin/achievements - Создание достижения
- PATCH /api/admin/achievements/:id - Редактирование достижения
- DELETE /api/admin/achievements/:id - Удаление достижения
- GET /api/admin/games/:gameId - Информация об игре
- DELETE /api/admin/games/:gameId - Удаление игры 